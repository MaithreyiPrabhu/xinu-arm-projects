/**
 * @file platform-local.h
 *
 */

#ifndef _ARM_QEMU_PLATFORM_LOCAL_H
#define _ARM_QEMU_PLATFORM_LOCAL_H

/* Max RAM addresses */

/* Time Base Frequency */

#endif /* _ARM_QEMU_PLATFORM_LOCAL_H */
