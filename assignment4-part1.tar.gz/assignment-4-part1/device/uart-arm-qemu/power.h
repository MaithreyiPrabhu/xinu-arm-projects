void set_bluetooth( int power );
