/**
 * @file platform-local.h
 *
 */

#ifndef _ARM_QEMU_PLATFORM_LOCAL_H
#define _ARM_QEMU_PLATFORM_LOCAL_H

#include <versatile-arm926ej-s.h>

#endif /* _ARM_QEMU_PLATFORM_LOCAL_H */
