void debugret( void )
{
    kill( gettid() );
}
