/*
 * Temporary debug functions for the Fluke.
 */

void setup_pins( void );
void led_on( void );
void led_off( void );
void die( void );
