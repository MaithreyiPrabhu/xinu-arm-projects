/**
 * @file mips.h
 *   Inherit main mips mips.h.
 */
/* Copyright 2012 Nathan Phillip Brink <ohnobinki@ohnopublishing.net> */

#include "../mipsel-qemu/mips.h"
