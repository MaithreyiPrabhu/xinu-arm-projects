/**
 * @file platform-local.h
 *   Inherit settings from main mips platform-local.h.
 */
/* Copyright 2012 Nathan Phillip Brink <ohnobinki@ohnopublishing.net> */

#include "../mipsel-qemu/platform-local.h"
