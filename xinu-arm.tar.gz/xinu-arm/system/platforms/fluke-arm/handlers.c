/**
 * Functions to handle ARM interrups. These are called
 *  by the jump table in loader/start-arm.S.
 */

void SWI_Routine( void )
{

}

void UNDEF_Routine( void )
{

}

void FIQ_Routine( void )
{

}
