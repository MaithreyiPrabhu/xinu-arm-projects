/**
 *  * @file wait.c
 *   * @provides wait.
 *    *
 *     * $Id: wait.c 2020 2009-08-13 17:50:08Z mschul $
 *      */
/* Embedded Xinu, Copyright (C) 2009.  All rights reserved. */

#include <thread.h>
#include <interrupt.h>
#include <future.h>

static future futmalloc();

future* future_alloc(int future_flags)
{
    	register future* fut;
	irqmask im;
    	im = disable();             /* disable interrupts    */
    
    	fut = malloc(sizeof(future));
 
    	*fut  = futmalloc();           /* request new future entry */
    	if (*fut != SYSERR)    /* safety check          */
    	{
		restore(im);            /* restore interrupts    */
        	return fut;             /* return the future   */
    	}
	
	restore(im);
    	return SYSERR;	
}

future futmalloc()
{
	int fut = 0;                /* future to return */
    	static int nextfut = 0;

    	for (fut = 0; fut < NFUT; fut++)
    	{
        	nextfut = (nextfut + 1) % NFUT;
        	if (SFREE == futtab[nextfut].state)
        	{
            		futtab[nextfut].state = FUSED;
            		return nextfut; 
        	}
    	}
    	return SYSERR;
}

syscall future_free(future* fut)
{
	register struct futent *entry;
	irqmask im;
	im = disable();
	if (isbadfuture(*fut))
    	{
        	restore(im);
        	return SYSERR;
    	}
	entry = &futtab[*fut];
	if(entry->state == CONSUMER_WAITING)
	{
		ready(entry->tid,RESCHED_YES);
	}	
	entry->state = FFREE;
	restore(im);
	return OK;
}

syscall future_get(future* fut, int* value)
{
	register struct futent *entry;
	register struct thrent *thrptr;
	irqmask im;
	im = disable();
	if(isbadfuture(*fut))
	{
		restore(im);
		return SYSERR;
	}
	entry = &futtab[*fut];
	if(entry->state == PRODUCED)
	{
		*value = *(entry->value);
		// since future is not going to be used by another consumer we delete
		// the future
		restore(im);
		return OK;	
	}
	else if(entry->state == FUSED)
	{
		entry->state = CONSUMER_WAITING;
		thrptr = &thrtab[thrcurrent];
		thrptr->state = THRWAIT;
		entry->tid = thrcurrent;
		resched();
	}
	*value = *(entry->value);
	restore(im);
	return OK;
}
	
syscall future_set(future* fut, int* value)
{
	register struct futent *entry;
	irqmask im;
	im = disable();
	if(isbadfuture(*fut))
	{
		restore(im);
		return OK;	
	}
	entry = &futtab[*fut];
	// storing the value for the future
	entry->value = value;
	if(entry->state == FUSED)
	{
		entry->state = PRODUCED;
	}	
	else if(entry->state == CONSUMER_WAITING)
	{
		entry->state = PRODUCED;
		ready(entry->tid,RESCHED_YES); 
	} 
	restore(im);
	return OK;	

}
